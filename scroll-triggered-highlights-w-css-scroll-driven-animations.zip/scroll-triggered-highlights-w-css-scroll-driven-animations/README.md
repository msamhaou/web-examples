# Scroll Triggered Highlights w/ CSS Scroll Driven Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/qBgRLxb](https://codepen.io/jh3y/pen/qBgRLxb).

