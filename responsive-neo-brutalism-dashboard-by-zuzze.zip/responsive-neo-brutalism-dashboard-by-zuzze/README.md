# Responsive Neo-brutalism Dashboard by Zuzze

A Pen created on CodePen.io. Original URL: [https://codepen.io/zuzze/pen/jOdYjdv](https://codepen.io/zuzze/pen/jOdYjdv).

Experimented with Neo-brutalism trend and retro illustrations as part of codepen challenge