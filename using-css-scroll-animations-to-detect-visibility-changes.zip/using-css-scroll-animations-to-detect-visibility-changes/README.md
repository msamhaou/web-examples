# Using CSS scroll animations to detect visibility changes

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/gOEQWpR](https://codepen.io/giana/pen/gOEQWpR).

A demo I made to illustrate [this demo](https://codepen.io/giana/pen/gOEQmVW/). It's a demo of a demo. Or how to complete misuse the toys you've been given.