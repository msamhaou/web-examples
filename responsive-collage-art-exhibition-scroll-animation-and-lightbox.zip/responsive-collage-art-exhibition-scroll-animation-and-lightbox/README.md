# Responsive Collage Art Exhibition | Scroll Animation and Lightbox

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/zYejYVy](https://codepen.io/ecemgo/pen/zYejYVy).

This responsive pen includes scroll animation by ScrollReveal. The background is created with the radial gradient. Also, CSS grid area is used for the gallery layout and it includes a lightbox to view the image wider.

Note: This project can be accessible but it is not meant for unlimited use. Please, do not use it in profit-making platforms and projects without permission.

Resource:
https://creator.nightcafe.studio/game/1ueLhDdzQU9K9eHH9mWf