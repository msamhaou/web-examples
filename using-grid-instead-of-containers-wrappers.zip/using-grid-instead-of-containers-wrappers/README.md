# Using grid instead of containers/wrappers

A Pen created on CodePen.io. Original URL: [https://codepen.io/kevinpowell/pen/ExrZrrw](https://codepen.io/kevinpowell/pen/ExrZrrw).

