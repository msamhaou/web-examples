# 2 cool ways to use :has()

A Pen created on CodePen.io. Original URL: [https://codepen.io/jlengstorf/pen/YzMwNrp](https://codepen.io/jlengstorf/pen/YzMwNrp).

